<!DOCTYPE HTML>
<html lang="en-US">
    <head>
        <script src="<?php echo $this->data['baseurlpath']; ?>/assets/js/redirect.js"></script>
        <title>Redirect to login</title>
    </head>
    <body>
        <p>Your browser seems to have Javascript disabled. Please click <a id="redirect" href="<?php echo $this->data['url']; ?>">here</a>.</p>
    </body>
</html>

