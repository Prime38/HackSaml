The icons in this directory is from the eXperience theme by
David Christian Berg. The icons are released under the GNU GPL.

See:
- http://art.gnome.org/themes/icon
- http://art.gnome.org/download/themes/icon/1096/ICON-EXperience.tar.gz
